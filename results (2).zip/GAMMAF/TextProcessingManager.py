import torch
from sentence_transformers import SentenceTransformer
from typing import List, Dict, Any

class RoundProcessor:
    def __init__(self, device=None):
        self.device = device if device else ("cuda" if torch.cuda.is_available() else "cpu")
        self.model = SentenceTransformer('all-MiniLM-L12-v2')
        self.model.to(self.device)

    def process_round(self, round_data: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        processed_agents = []

        for agent in round_data:
            processed_agent = agent.copy()

            if "reason" in agent and agent["reason"]:
                st_embedding = self.model.encode(
                    agent["reason"],
                    device=self.device,
                    show_progress_bar=False
                ).tolist()
                processed_agent["st_embedding"] = st_embedding
                processed_agent["tk_embedding"] = [st_embedding] 

            processed_agents.append(processed_agent)

        return processed_agents
